package com.sb.demo.model;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.*;
import lombok.*;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class ProductDto {
    @NotEmpty(message="This Field is Required")
    private String name;
    @NotEmpty(message="This Field is Required")
    private String brand;
    @NotEmpty(message="This Field is Required")
    private String category;
   @Min(0)
    private double price;
  @Size(min=0 ,message="The Description Should be at least 10 characters")
  @Size(max=2000,message="The Description Should be at most 2000 characters")
    private String description;
  
  private MultipartFile imagefile;
}
