package com.sb.demo.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sb.demo.model.Product;

public interface Productrepo extends JpaRepository<Product,Integer> {

}
