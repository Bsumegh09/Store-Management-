package com.sb.demo.Controller;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.sb.demo.model.Product;
import com.sb.demo.model.ProductDto;
import com.sb.demo.service.Productrepo;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/products")
public class Productcontroller {

    @Autowired
    private Productrepo productRepo;

    @GetMapping({"", "/"})
    public String showProductList(Model model) {
        List<Product> products = productRepo.findAll();
        model.addAttribute("products", products);
        return "productsUI/proindex"; // Assuming "pindex.html" exists in src/main/resources/templates/
    }

    @GetMapping("/create")
    public String showCreatePage(Model model) {
        ProductDto productdto = new ProductDto();
        model.addAttribute("productdto", productdto);
        return "productsUI/createProduct";
    }

    @PostMapping("/create")
    public String createProduct(
            @Valid @ModelAttribute("productdto") ProductDto productdto,
            BindingResult result,
            Model model
    ) {
        if (productdto.getImagefile().isEmpty()) {
            result.addError(new FieldError("productdto", "imagefile", "The image File is Required"));
        }
        if (result.hasErrors()) {
            model.addAttribute("productdto", productdto); // Add this line to ensure productdto is available in the model
            return "productsUI/createProduct";
        }
        // Save the product (not shown in your original code)
        // productRepo.save(productdto.toProduct()); // Assuming a method to convert DTO to entity
        MultipartFile image=productdto.getImagefile();
        Date createdAt=new Date();
        String storageFileName=createdAt.getTime()+"_"+image.getOriginalFilename();
        try {
        	String uploadDir="public/images/";
        	Path uploadPath=Paths.get(uploadDir);
        	if(!Files.exists(uploadPath))
        	{
        		Files.createDirectory(uploadPath);
        	}
        	try(InputStream inputStream =image.getInputStream())
        	{
        		Files.copy(inputStream, Paths.get(uploadDir+storageFileName),
        				StandardCopyOption.REPLACE_EXISTING);
        	}
        }
        catch(Exception ex)
        {
        	System.out.println("Exception Occured "+ ex.getMessage());
        }
        Product product=new Product();
        product.setName(productdto.getName());
        product.setBrand(productdto.getBrand());
        product.setCategory(productdto.getCategory());
        product.setPrice(productdto.getPrice());
        product.setDescription(productdto.getDescription());
        product.setCreatedAt(createdAt);
        product.setImagefileName(storageFileName);
        productRepo.save(product);
        return "redirect:/products";
    }
    @GetMapping("/edit")
    public String showEditPage(
    		Model model,
    		@RequestParam int id
    		)
    {  try {
    	Product product=productRepo.findById(id).get();
    	model.addAttribute("product",product);
    	ProductDto productdto=new ProductDto();
    	productdto.setName(product.getName());
    	productdto.setBrand(product.getBrand());
    	productdto.setCategory(product.getCategory());
    	productdto.setPrice(product.getPrice());
    	productdto.setDescription(product.getDescription());
    	model.addAttribute("productdto",productdto);
    }
    catch(Exception e)
    {
    	System.out.println("Exception "+e.getMessage());
    	return "redirect:/products";
    }
    	return "productsUI/Editproduct";
    }
    @PostMapping("/edit")
    public String updateProduct(
    		Model model,
    		@RequestParam int id,
    		@Valid @ModelAttribute ("productdto") ProductDto productdto,
    		BindingResult result
    		)
    {
    	try {
    		Product product =productRepo.findById(id).get();
    		model.addAttribute("product", product);
    		if(result.hasErrors())
    		{
    			return "productsUI/Editproduct";
    		}
            if(!productdto.getImagefile().isEmpty())
            {  //Deleting Old Image in Dataset
            	String uploadDir="public/images/";
            	Path oldImagePath=Paths.get(uploadDir+product.getImagefileName());
            	try {
            		Files.delete(oldImagePath);
            	}
            	catch(Exception e)
            	{
            		System.out.println("Exception "+e.getMessage());
            	}
            	//Saving Image New Image
            	MultipartFile image=productdto.getImagefile();
            	Date createdAt=new Date();
            	String storageFileName=createdAt.getTime()+"_"+image.getOriginalFilename();
            	try(InputStream inputStream =image.getInputStream())
            	{
            		Files.copy(inputStream, Paths.get(uploadDir+storageFileName),
            				StandardCopyOption.REPLACE_EXISTING);
            	}
            	product.setImagefileName(storageFileName);
            }
            product.setName(productdto.getName());
            product.setBrand(productdto.getBrand());
            product.setCategory(productdto.getCategory());
            product.setPrice(productdto.getPrice());
            product.setDescription(productdto.getDescription());
            productRepo.save(product);
    	}
    	catch(Exception e)
    	{
    		System.out.println("Exception"+e.getMessage());
    	}
    	return "redirect:/products";
    }
    
    //Deleting
    @GetMapping("/delete")
    public String deleteproduct(
    		@RequestParam int id
    		)
    {    try {
    	   Product product=productRepo.findById(id).get();
    	   Path imagepath=Paths.get("public/images/"+product.getImagefileName());
    	   try {
    		   Files.delete(imagepath);
    	   }
    	   catch(Exception e)
    	   {
    		   System.out.println("Exception "+e.getMessage());
    	   }
    	   productRepo.delete(product);
    	   
    }
    catch(Exception e)
    {
    	System.out.println("Exception "+e.getMessage());
    }
    	return "redirect:/products";
    }
    
}
